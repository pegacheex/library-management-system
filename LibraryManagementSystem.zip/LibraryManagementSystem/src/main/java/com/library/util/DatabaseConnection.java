package com.library.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/library_db";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create books table
            stmt.execute("CREATE TABLE IF NOT EXISTS books (" +
                "id VARCHAR(50) PRIMARY KEY," +
                "title VARCHAR(255) NOT NULL," +
                "author VARCHAR(255) NOT NULL," +
                "availability VARCHAR(50) NOT NULL" +
                ")");

            // Create members table
            stmt.execute("CREATE TABLE IF NOT EXISTS members (" +
                "id VARCHAR(50) PRIMARY KEY," +
                "name VARCHAR(255) NOT NULL," +
                "email VARCHAR(255) NOT NULL," +
                "phone VARCHAR(50) NOT NULL," +
                "address TEXT" +
                ")");

            // Create borrowed_books table
            stmt.execute("CREATE TABLE IF NOT EXISTS borrowed_books (" +
                "id VARCHAR(50) PRIMARY KEY," +
                "book_id VARCHAR(50) NOT NULL," +
                "book_title VARCHAR(255) NOT NULL," +
                "member_id VARCHAR(50) NOT NULL," +
                "member_name VARCHAR(255) NOT NULL," +
                "borrow_date DATE NOT NULL," +
                "due_date DATE NOT NULL," +
                "return_date DATE," +
                "status VARCHAR(50) NOT NULL," +
                "FOREIGN KEY (book_id) REFERENCES books(id)," +
                "FOREIGN KEY (member_id) REFERENCES members(id)" +
                ")");

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize database: " + e.getMessage());
        }
    }
} 