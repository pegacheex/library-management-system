package com.library.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.control.cell.PropertyValueFactory;
import com.library.model.Book;
import com.library.model.Member;
import com.library.model.BorrowedBook;
import com.library.dao.LibraryDAO;
import com.library.util.DatabaseConnection;
import java.util.Optional;
import java.time.LocalDate;
import java.sql.SQLException;

public class MainController {
    private final LibraryDAO libraryDAO = new LibraryDAO();

    @FXML private VBox dashboardView;
    @FXML private VBox booksView;
    @FXML private VBox membersView;
    @FXML private VBox borrowedView;
    
    @FXML private Button dashboardButton;
    @FXML private Button booksButton;
    @FXML private Button membersButton;
    @FXML private Button borrowedButton;
    
    @FXML private Label totalBooksLabel;
    @FXML private Label totalMembersLabel;
    @FXML private Label booksBorrowedLabel;
    
    @FXML private TableView<Book> booksTable;
    @FXML private TableColumn<Book, String> idColumn;
    @FXML private TableColumn<Book, String> titleColumn;
    @FXML private TableColumn<Book, String> authorColumn;
    @FXML private TableColumn<Book, String> availabilityColumn;
    @FXML private TableColumn<Book, Void> actionsColumn;
    
    @FXML private TextField searchField;
    @FXML private TextField memberSearchField;
    @FXML private TextField borrowedSearchField;

    // Members table
    @FXML private TableView<Member> membersTable;
    @FXML private TableColumn<Member, String> memberIdColumn;
    @FXML private TableColumn<Member, String> memberNameColumn;
    @FXML private TableColumn<Member, String> memberEmailColumn;
    @FXML private TableColumn<Member, String> memberPhoneColumn;
    @FXML private TableColumn<Member, Void> memberActionsColumn;
    
    // Borrowed books table
    @FXML private TableView<BorrowedBook> borrowedTable;
    @FXML private TableColumn<BorrowedBook, String> borrowedBookIdColumn;
    @FXML private TableColumn<BorrowedBook, String> borrowedBookTitleColumn;
    @FXML private TableColumn<BorrowedBook, String> borrowedMemberNameColumn;
    @FXML private TableColumn<BorrowedBook, LocalDate> borrowDateColumn;
    @FXML private TableColumn<BorrowedBook, LocalDate> dueDateColumn;
    @FXML private TableColumn<BorrowedBook, String> statusColumn;
    @FXML private TableColumn<BorrowedBook, Void> borrowedActionsColumn;

    @FXML
    public void initialize() {
        // Initialize database tables
        DatabaseConnection.initializeDatabase();

        // Initialize book table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
        availabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));
        
        // Initialize member table columns
        memberIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        memberNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        memberEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        memberPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        
        // Initialize borrowed books table columns
        borrowedBookIdColumn.setCellValueFactory(new PropertyValueFactory<>("bookId"));
        borrowedBookTitleColumn.setCellValueFactory(new PropertyValueFactory<>("bookTitle"));
        borrowedMemberNameColumn.setCellValueFactory(new PropertyValueFactory<>("memberName"));
        borrowDateColumn.setCellValueFactory(new PropertyValueFactory<>("borrowDate"));
        dueDateColumn.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        
        // Load initial data
        loadDashboardData();
        loadBooksData();
        loadMembersData();
        loadBorrowedBooksData();
    }

    @FXML
    private void handleDashboardClick() {
        showView(dashboardView);
        updateNavButtons(dashboardButton);
        loadDashboardData();
    }

    @FXML
    private void handleBooksClick() {
        showView(booksView);
        updateNavButtons(booksButton);
        loadBooksData();
    }

    @FXML
    private void handleMembersClick() {
        showView(membersView);
        updateNavButtons(membersButton);
        loadMembersData();
    }

    @FXML
    private void handleBorrowedClick() {
        showView(borrowedView);
        updateNavButtons(borrowedButton);
        loadBorrowedBooksData();
    }

    @FXML
    private void handleAddBook() {
        Dialog<Book> dialog = new Dialog<>();
        dialog.setTitle("Add New Book");
        dialog.setHeaderText("Enter book details");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField titleField = new TextField();
        titleField.setPromptText("Title");
        TextField authorField = new TextField();
        authorField.setPromptText("Author");

        VBox content = new VBox(10);
        content.getChildren().addAll(
            new Label("Title:"), titleField,
            new Label("Author:"), authorField
        );
        dialogPane.setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                return new Book(
                    String.valueOf(System.currentTimeMillis()),
                    titleField.getText(),
                    authorField.getText(),
                    "Available"
                );
            }
            return null;
        });

        Optional<Book> result = dialog.showAndWait();
        result.ifPresent(book -> {
            try {
                libraryDAO.addBook(book);
                loadBooksData();
                loadDashboardData();
            } catch (SQLException e) {
                showError("Database Error", "Failed to add book: " + e.getMessage());
            }
        });
    }

    @FXML
    private void handleSearchBooks() {
        String searchText = searchField.getText().toLowerCase();
        // Implement search functionality
    }

    @FXML
    private void handleAddMember() {
        Dialog<Member> dialog = new Dialog<>();
        dialog.setTitle("Add New Member");
        dialog.setHeaderText("Enter member details");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField phoneField = new TextField();
        phoneField.setPromptText("Phone");
        TextField addressField = new TextField();
        addressField.setPromptText("Address");

        VBox content = new VBox(10);
        content.getChildren().addAll(
            new Label("Name:"), nameField,
            new Label("Email:"), emailField,
            new Label("Phone:"), phoneField,
            new Label("Address:"), addressField
        );
        dialogPane.setContent(content);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                return new Member(
                    String.valueOf(System.currentTimeMillis()),
                    nameField.getText(),
                    emailField.getText(),
                    phoneField.getText(),
                    addressField.getText()
                );
            }
            return null;
        });

        Optional<Member> result = dialog.showAndWait();
        result.ifPresent(member -> {
            try {
                libraryDAO.addMember(member);
                loadMembersData();
                loadDashboardData();
            } catch (SQLException e) {
                showError("Database Error", "Failed to add member: " + e.getMessage());
            }
        });
    }

    @FXML
    private void handleBorrowBook() {
        try {
            if (libraryDAO.getAllBooks().isEmpty() || libraryDAO.getAllMembers().isEmpty()) {
                showError("Cannot Borrow Book", "Please add books and members first.");
                return;
            }

            Dialog<BorrowedBook> dialog = new Dialog<>();
            dialog.setTitle("Borrow Book");
            dialog.setHeaderText("Select book and member");

            DialogPane dialogPane = dialog.getDialogPane();
            dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

            ComboBox<Book> bookComboBox = new ComboBox<>();
            bookComboBox.getItems().addAll(libraryDAO.getAllBooks());
            bookComboBox.setPromptText("Select Book");
            bookComboBox.setCellFactory(param -> new ListCell<Book>() {
                @Override
                protected void updateItem(Book book, boolean empty) {
                    super.updateItem(book, empty);
                    setText(empty ? null : book.getTitle());
                }
            });

            ComboBox<Member> memberComboBox = new ComboBox<>();
            memberComboBox.getItems().addAll(libraryDAO.getAllMembers());
            memberComboBox.setPromptText("Select Member");
            memberComboBox.setCellFactory(param -> new ListCell<Member>() {
                @Override
                protected void updateItem(Member member, boolean empty) {
                    super.updateItem(member, empty);
                    setText(empty ? null : member.getName());
                }
            });

            VBox content = new VBox(10);
            content.getChildren().addAll(
                new Label("Book:"), bookComboBox,
                new Label("Member:"), memberComboBox
            );
            dialogPane.setContent(content);

            dialog.setResultConverter(dialogButton -> {
                if (dialogButton == ButtonType.OK) {
                    Book selectedBook = bookComboBox.getValue();
                    Member selectedMember = memberComboBox.getValue();
                    if (selectedBook != null && selectedMember != null) {
                        return new BorrowedBook(
                            String.valueOf(System.currentTimeMillis()),
                            selectedBook.getId(),
                            selectedBook.getTitle(),
                            selectedMember.getId(),
                            selectedMember.getName(),
                            LocalDate.now(),
                            LocalDate.now().plusDays(14)
                        );
                    }
                }
                return null;
            });

            Optional<BorrowedBook> result = dialog.showAndWait();
            result.ifPresent(borrowed -> {
                try {
                    libraryDAO.addBorrowedBook(borrowed);
                    libraryDAO.updateBookAvailability(borrowed.getBookId(), "Not Available");
                    loadBorrowedBooksData();
                    loadBooksData();
                    loadDashboardData();
                } catch (SQLException e) {
                    showError("Database Error", "Failed to process book borrowing: " + e.getMessage());
                }
            });
        } catch (SQLException e) {
            showError("Database Error", "Failed to load data for borrowing: " + e.getMessage());
        }
    }

    private void showView(VBox view) {
        dashboardView.setVisible(false);
        dashboardView.setManaged(false);
        booksView.setVisible(false);
        booksView.setManaged(false);
        membersView.setVisible(false);
        membersView.setManaged(false);
        borrowedView.setVisible(false);
        borrowedView.setManaged(false);

        view.setVisible(true);
        view.setManaged(true);
    }

    private void updateNavButtons(Button activeButton) {
        String inactiveStyle = "-fx-background-color: transparent; -fx-text-fill: #666;";
        String activeStyle = "-fx-background-color: #4285f4; -fx-text-fill: white;";

        dashboardButton.setStyle(inactiveStyle);
        booksButton.setStyle(inactiveStyle);
        membersButton.setStyle(inactiveStyle);
        borrowedButton.setStyle(inactiveStyle);

        activeButton.setStyle(activeStyle);
    }

    private void loadDashboardData() {
        try {
            int totalBooks = libraryDAO.getAllBooks().size();
            int totalMembers = libraryDAO.getAllMembers().size();
            long borrowedCount = libraryDAO.getAllBorrowedBooks().stream()
                .filter(b -> b.getStatus().equals("Borrowed"))
                .count();

            totalBooksLabel.setText(String.valueOf(totalBooks));
            totalMembersLabel.setText(String.valueOf(totalMembers));
            booksBorrowedLabel.setText(String.valueOf(borrowedCount));
        } catch (SQLException e) {
            showError("Database Error", "Failed to load dashboard data: " + e.getMessage());
        }
    }

    private void loadBooksData() {
        try {
            booksTable.getItems().clear();
            booksTable.getItems().addAll(libraryDAO.getAllBooks());
        } catch (SQLException e) {
            showError("Database Error", "Failed to load books data: " + e.getMessage());
        }
    }

    private void loadMembersData() {
        try {
            membersTable.getItems().clear();
            membersTable.getItems().addAll(libraryDAO.getAllMembers());
        } catch (SQLException e) {
            showError("Database Error", "Failed to load members data: " + e.getMessage());
        }
    }

    private void loadBorrowedBooksData() {
        try {
            borrowedTable.getItems().clear();
            borrowedTable.getItems().addAll(libraryDAO.getAllBorrowedBooks());
        } catch (SQLException e) {
            showError("Database Error", "Failed to load borrowed books data: " + e.getMessage());
        }
    }

    @FXML
    private void handleSearchMembers() {
        String searchText = memberSearchField.getText().toLowerCase();
        // Implement member search
    }

    @FXML
    private void handleSearchBorrowed() {
        String searchText = borrowedSearchField.getText().toLowerCase();
        // Implement borrowed books search
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 