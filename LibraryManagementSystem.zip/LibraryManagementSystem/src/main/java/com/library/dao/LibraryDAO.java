package com.library.dao;

import com.library.model.Book;
import com.library.model.Member;
import com.library.model.BorrowedBook;
import com.library.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LibraryDAO {
    
    // Book operations
    public void addBook(Book book) throws SQLException {
        String sql = "INSERT INTO books (id, title, author, availability) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, book.getId());
            pstmt.setString(2, book.getTitle());
            pstmt.setString(3, book.getAuthor());
            pstmt.setString(4, book.getAvailability());
            pstmt.executeUpdate();
        }
    }

    public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Book book = new Book(
                    rs.getString("id"),
                    rs.getString("title"),
                    rs.getString("author"),
                    rs.getString("availability")
                );
                books.add(book);
            }
        }
        return books;
    }

    public void updateBookAvailability(String bookId, String availability) throws SQLException {
        String sql = "UPDATE books SET availability = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, availability);
            pstmt.setString(2, bookId);
            pstmt.executeUpdate();
        }
    }

    // Member operations
    public void addMember(Member member) throws SQLException {
        String sql = "INSERT INTO members (id, name, email, phone, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, member.getId());
            pstmt.setString(2, member.getName());
            pstmt.setString(3, member.getEmail());
            pstmt.setString(4, member.getPhone());
            pstmt.setString(5, member.getAddress());
            pstmt.executeUpdate();
        }
    }

    public List<Member> getAllMembers() throws SQLException {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM members";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Member member = new Member(
                    rs.getString("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("address")
                );
                members.add(member);
            }
        }
        return members;
    }

    // Borrowed book operations
    public void addBorrowedBook(BorrowedBook borrowedBook) throws SQLException {
        String sql = "INSERT INTO borrowed_books (id, book_id, book_title, member_id, member_name, " +
                    "borrow_date, due_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, borrowedBook.getId());
            pstmt.setString(2, borrowedBook.getBookId());
            pstmt.setString(3, borrowedBook.getBookTitle());
            pstmt.setString(4, borrowedBook.getMemberId());
            pstmt.setString(5, borrowedBook.getMemberName());
            pstmt.setDate(6, Date.valueOf(borrowedBook.getBorrowDate()));
            pstmt.setDate(7, Date.valueOf(borrowedBook.getDueDate()));
            pstmt.setString(8, borrowedBook.getStatus());
            pstmt.executeUpdate();
        }
    }

    public List<BorrowedBook> getAllBorrowedBooks() throws SQLException {
        List<BorrowedBook> borrowedBooks = new ArrayList<>();
        String sql = "SELECT * FROM borrowed_books";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                BorrowedBook borrowedBook = new BorrowedBook(
                    rs.getString("id"),
                    rs.getString("book_id"),
                    rs.getString("book_title"),
                    rs.getString("member_id"),
                    rs.getString("member_name"),
                    rs.getDate("borrow_date").toLocalDate(),
                    rs.getDate("due_date").toLocalDate()
                );
                if (rs.getDate("return_date") != null) {
                    borrowedBook.setReturnDate(rs.getDate("return_date").toLocalDate());
                }
                borrowedBook.setStatus(rs.getString("status"));
                borrowedBooks.add(borrowedBook);
            }
        }
        return borrowedBooks;
    }

    public void updateBorrowedBookStatus(String id, String status, LocalDate returnDate) throws SQLException {
        String sql = "UPDATE borrowed_books SET status = ?, return_date = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setDate(2, returnDate != null ? Date.valueOf(returnDate) : null);
            pstmt.setString(3, id);
            pstmt.executeUpdate();
        }
    }
} 