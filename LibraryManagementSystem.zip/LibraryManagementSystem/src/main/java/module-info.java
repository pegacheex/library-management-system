module com.library {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;

    opens com.library to javafx.fxml;
    opens com.library.controller to javafx.fxml;
    opens com.library.model to javafx.base;
    
    exports com.library;
    exports com.library.controller;
    exports com.library.model;
    exports com.library.dao;
    exports com.library.util;
} 